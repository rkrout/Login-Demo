<?php 

$page_config = [
    "page_title" => "Happy Fox Api - Staff Performance",
    "table_title" => "Staff Performance",
    "show_home" => true
];

require("header.php");

?>

<div class="card-body">
    <div class="table-responsive"> 
        <table id="happytable" class="table table-bordered table-striped w-100">
            <thead>
                <tr>
                    <th>Avg Time Spend</th>
                    <th>Staff ID</th>
                    <th>Avg no of responses</th>
                    <th>Avg time to ticket completed</th>
                    <th>Avg first response time</th>
                    <th>Avg response time</th>
                    <th>Avg no of responses per completation</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<?php require("footer.php") ?>

<script>
    const table = $('#happytable').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        responsive: true,
        ordering: false,
        ajax: '/happyfox/api_happyfox.php?action=get_staff_performance',
        columns: [
            { data: 'average_time_spent' },
            { data: 'staff_id' },
            { data: 'average_no_of_responses' },
            { data: 'average_time_to_ticket_complete' },
            { data: 'average_first_response_time' },
            { data: 'average_response_time' },
            { data: 'average_no_of_responses_for_completion' }
        ]
    });

    setInterval(function () {
        table.draw()
    }, 30000)
</script>

