<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= $page_config["page_title"] ?? "Happy Fox Api" ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

    <!-- Jquery Links -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>

    <!-- Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Date range picker links -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <!-- Data table links -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>

    <style>
        .progressbar{
            position: relative;
            height: 12px;
            /*width: 1110%;*/
            border: 2px solid #2e6da4;
            border-radius: 15px;
            margin: 0 20px;
        }
        .progressbar .color{
            position: absolute;
            background-color: #496ed5;
            width: 0px;
            height: 10px;
            border-radius: 15px;
            animation: progres 30s infinite linear;    
        }
        .dataTables_length {
            margin-bottom: 16px;
        }
        @keyframes progres{
            0%{
            width: 0%;
            }
            25%{
                width: 50%;
            }
            50%{
                width: 75%;
            }
            75%{
                width: 85%;
            }
            100%{
                width: 100%;
            }
        };
    </style>
</head>
<body>
    <!-- Start of container -->
    <div class="container mt-4">
        <div class="row align-items-center mb-4">
            <div class="col-3">
                <buton class="btn btn-sm btn-dark" onclick="history.go(-1)">
                    <i class="fa fa-arrow-left me-1"></i>
                    Back to BST
                </buton>
            </div>

            <div class="col-6 d-flex align-items-center justify-content-center gap-3">
                <img src="/happyfox/happfoxlogo.png" width="50px">
                <h2>HAPPY FOX API</h2>
            </div>

            <div class="col-3">
                
            </div>
        </div>

        <!-- Start of card -->
        <div class="card mb-5">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span class="fw-bold text-primary"><?= $page_config["table_title"] ?></span>
                <div class="d-flex align-items-center gap-2">
                    <?php if(isset($page_config["show_home"]) && $page_config["show_home"]): ?>
                        <a href="/happyfox" class="btn btn-sm btn-primary" type="button" data-bs-name="tooltip" data-bs-title="Home">
                            <i class="fa fa-home"></i>
                        </a>
                    <?php endif; ?>

                    <div class="dropdown">
                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa fa-eye"></i>
                            View
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/happyfox/staff-activity.php">Staff Activity</a></li>
                            <li><a class="dropdown-item" href="/happyfox/staff-performance.php">Staff Performance</a></li>
                        </ul>
                    </div>

                    <?php if(isset($page_config["show_add"]) && $page_config["show_add"]): ?>
                        <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                            <i class="fa fa-plus"></i>
                            Add new
                        </button>
                    <?php endif; ?>

                    <button class="btn-theme btn btn-sm btn-warning" type="button">
                        <i class="fa-regular fa-moon"></i>
                        <span>Theme</span>
                    </button>
                </div>
            </div>
