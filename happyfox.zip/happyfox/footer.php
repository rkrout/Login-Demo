            <div class="card-footer text-center">
                <img src="/happyfox/bst_applogo.png" width="100px">
            </div>
        </div>
        <!-- End of card -->
    </div>
    <!-- End of container -->
</body>
</html>

<script>
    $("body").attr("data-bs-theme", localStorage.getItem("currentTheme") ? localStorage.getItem("currentTheme") : "light")

    $(".btn-theme").click(function(){
        let currentTheme = $("body").attr("data-bs-theme")

        currentTheme = currentTheme == "light" ? "dark" : "light"

        $("body").attr("data-bs-theme", currentTheme)

        localStorage.setItem("currentTheme", currentTheme)

        updateThemeButton()
    })

    function updateThemeButton() 
    {
        const currentTheme = localStorage.getItem("currentTheme") ? localStorage.getItem("currentTheme") : "light"

        if(currentTheme == "light")
        {
            $(".btn-theme").find("i").addClass("fa-moon")
            $(".btn-theme").find("i").removeClass("fa-sun")
            $(".btn-theme").find("span").html("Dark")
        }
        else 
        {
            $(".btn-theme").find("i").addClass("fa-sun")
            $(".btn-theme").find("i").removeClass("fa-moon")
            $(".btn-theme").find("span").html("Light")
        }
    }

    $("[data-bs-name=tooltip]").each(function() {
        new bootstrap.Tooltip($(this).get(0))
    })

    updateThemeButton()
</script>