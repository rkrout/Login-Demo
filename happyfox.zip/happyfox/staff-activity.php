<?php 

$page_config = [
    "page_title" => "Happy Fox Api - Staff Activity",
    "table_title" => "Staff Activity",
    "show_home" => true
];

require("header.php");

?>

<div class="card-body">
    <div class="table-responsive"> 
        <table id="happytable" class="table table-bordered table-striped w-100">
            <thead>
                <tr>
                    <th>Assigned</th>
                    <th>Staff ID</th>
                    <th>Name</th>
                    <th>Private Notes</th>
                    <th>No of replies</th>
                    <th>Completed</th>
                    <th>Time Spent</th>
                    <th>Participated</th>
                    <th>Pending</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<?php require("footer.php") ?>

<script>
    const table = $('#happytable').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        responsive: true,
        ordering: false,
        columnDefs: [
            { width: "150px", orderable: false, targets: 1 }
        ],
        order: [
            [1, 'desc']
        ],
        ajax: 'api_happyfox.php?action=get_staff_activities',
        columns: [
            { data: 'assigned' },
            { data: 'staff_id' },
            { data: 'name' },
            { data: 'private_notes' },
            { data: 'no_of_replies' },
            { data: 'completed' },
            { data: 'time_spent' },
            { data: 'participated' },
            { data: 'pending' }
        ]
    })

    setInterval(function () {
        table.draw()
    }, 30000)
</script>
